//
//  NotificationController.swift
//  PawsomeWatch Extension
//
//  Created by Jaspreet Pannu on 24/08/20.
//  Copyright © 2020 Jaspreet. All rights reserved.
//

import WatchKit

class CatImageRowController: NSObject {
  
  @IBOutlet weak var catImage: WKInterfaceImage!

}
