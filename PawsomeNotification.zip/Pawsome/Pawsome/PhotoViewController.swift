//
//  NotificationController.swift
//  PawsomeWatch Extension
//
//  Created by Jaspreet Pannu on 24/08/20.
//  Copyright © 2020 Jaspreet. All rights reserved.
//

import UIKit

class PhotoViewController: UIViewController {
  
  var image: UIImage? = UIImage()
  @IBOutlet weak var imageView: UIImageView!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    imageView.image = image
  }
  
  @IBAction func didTap(_ sender: UITapGestureRecognizer) {
    dismiss(animated: true, completion: nil)
  }
}
